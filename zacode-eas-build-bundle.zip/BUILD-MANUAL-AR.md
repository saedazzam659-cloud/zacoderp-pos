# بناء AAB سحابي والرفع اليدوي

1. فك ضغط الحزمة إلى مجلد جديد.
2. افتح PowerShell في المجلد الذي يحتوي على `pnpm-workspace.yaml`.
3. ثبّت اعتماديات تطبيق الموبايل والحزمة المشتركة:
   `npx.cmd -y pnpm@10.26.1 install --filter "@workspace/mobile..." --frozen-lockfile`
4. انتقل إلى مجلد التطبيق:
   `cd artifacts\mobile`
5. تأكد من حساب Expo:
   `npx.cmd -y eas-cli@latest whoami`
6. اعرض رقم Android المخزن على EAS قبل البناء:
   `npx.cmd -y eas-cli@latest build:version:get --platform android --json`
   لا تبدأ البناء إذا كان الرقم أقل من 17؛ يجب ضبط الرقم البعيد إلى آخر رقم منشور قبل أن يزيده ملف الإنتاج تلقائياً.
7. بعد التأكد من رقم النسخة ومفتاح التوقيع، ابدأ البناء السحابي:
   `npx.cmd -y eas-cli@latest build --platform android --profile production`

هذا يبني ملف AAB على سحابة Expo ولا يربط Google Play ولا يرفع إليه. إذا طلب EAS إنشاء مفتاح Android جديد أو استبداله، أوقف العملية قبل الموافقة.
