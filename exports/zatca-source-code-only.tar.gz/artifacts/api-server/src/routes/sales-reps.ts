import { Router } from "express";
import { db } from "@workspace/db";
import {
  salesRepsTable,
  salesRepVisitsTable,
  customersTable,
  salesInvoicesTable,
  receiptVouchersTable, // used by delete guard so we don't orphan collection-commission history
} from "@workspace/db";
import { and, desc, eq, sql, inArray } from "drizzle-orm";
import { extractAuth, resolveCompanyId } from "../middleware/auth.js";
import { moduleAudit, requireModulePermission } from "../middleware/permissions.js";
import { ensureLeafAccounts } from "../lib/leafAccount.js";
import Anthropic from "@anthropic-ai/sdk";

const router = Router();
router.use(extractAuth);
router.use(requireModulePermission("sales_invoices"));
router.use(moduleAudit("sales_invoices"));
// Require an authenticated user for every sales-reps endpoint — these contain
// PII (phone/email/address) and commission terms; never serve to anonymous callers.
router.use((req, res, next) => {
  if (!req.authUser) { res.status(401).json({ error: "غير مصرح" }); return; }
  next();
});

function guard(req: any, res: any): number | null {
  const cid = resolveCompanyId(req, req.body?.companyId ?? req.query.companyId);
  if (!cid) { res.status(401).json({ error: "غير مصرح" }); return null; }
  return cid;
}
function requireCid(req: any, res: any): number | null {
  const raw = req.query.companyId ? Number(req.query.companyId) : undefined;
  const cid = resolveCompanyId(req, raw);
  if (!cid) { res.status(401).json({ error: "غير مصرح" }); return null; }
  return cid;
}

async function nextRepCode(cid: number): Promise<string> {
  const rows = await db.select({ code: salesRepsTable.code }).from(salesRepsTable)
    .where(eq(salesRepsTable.companyId, cid));
  let max = 0;
  for (const r of rows) {
    const m = /^(?:SR|SREP|REP)?(\d+)$/.exec(String(r.code).trim());
    if (m) { const n = parseInt(m[1], 10); if (Number.isFinite(n) && n > max) max = n; }
  }
  return `SR${String(max + 1).padStart(4, "0")}`;
}

// ─── REPS LIST/CRUD ──────────────────────────────────────────────────────────
router.get("/", async (req, res) => {
  try {
    const cid = requireCid(req, res); if (!cid) return;
    const rows = await db.select().from(salesRepsTable)
      .where(eq(salesRepsTable.companyId, cid))
      .orderBy(desc(salesRepsTable.id));
    res.json(rows);
  } catch (e: any) { res.status(500).json({ error: e.message }); }
});

router.get("/active", async (req, res) => {
  try {
    const cid = requireCid(req, res); if (!cid) return;
    const rows = await db.select().from(salesRepsTable)
      .where(and(eq(salesRepsTable.companyId, cid), eq(salesRepsTable.isActive, true)))
      .orderBy(salesRepsTable.nameAr);
    res.json(rows);
  } catch (e: any) { res.status(500).json({ error: e.message }); }
});

router.get("/:id", async (req, res) => {
  try {
    const cid = requireCid(req, res); if (!cid) return;
    const id = Number(req.params.id);
    const [row] = await db.select().from(salesRepsTable)
      .where(and(eq(salesRepsTable.id, id), eq(salesRepsTable.companyId, cid)));
    if (!row) { res.status(404).json({ error: "المندوب غير موجود" }); return; }
    res.json(row);
  } catch (e: any) { res.status(500).json({ error: e.message }); }
});

router.post("/", async (req, res) => {
  try {
    const cid = guard(req, res); if (!cid) return;
    const b = req.body ?? {};
    const nameAr = String(b.nameAr ?? "").trim();
    if (!nameAr) { res.status(400).json({ error: "اسم المندوب مطلوب" }); return; }
    const code = String(b.code ?? "").trim() || await nextRepCode(cid);

    if (b.accountId) {
      try { await ensureLeafAccounts(cid, [b.accountId]); }
      catch (err: any) { res.status(400).json({ error: err?.message ?? "حساب غير صالح" }); return; }
    }

    const [row] = await db.insert(salesRepsTable).values({
      companyId:      cid,
      code,
      nameAr,
      nameEn:         b.nameEn || null,
      phone:          b.phone || null,
      email:          b.email || null,
      address:        b.address || null,
      branchId:       b.branchId ? Number(b.branchId) : null,
      region:         b.region || null,
      isActive:       b.isActive !== false,
      commissionPct:  b.commissionPct != null ? String(b.commissionPct) : "0",
      commissionType: b.commissionType === "collection" ? "collection" : "invoice",
      monthlyTarget:  b.monthlyTarget != null ? String(b.monthlyTarget) : "0",
      accountId:      b.accountId ? Number(b.accountId) : null,
      notes:          b.notes || null,
    }).returning();
    res.status(201).json(row);
  } catch (e: any) {
    if (String(e?.message).includes("duplicate") || e?.code === "23505")
      return res.status(409).json({ error: "كود المندوب مستخدم مسبقاً" });
    res.status(500).json({ error: e.message });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const cid = guard(req, res); if (!cid) return;
    const id = Number(req.params.id);
    const b = req.body ?? {};

    if (b.accountId) {
      try { await ensureLeafAccounts(cid, [b.accountId]); }
      catch (err: any) { res.status(400).json({ error: err?.message ?? "حساب غير صالح" }); return; }
    }

    const [row] = await db.update(salesRepsTable).set({
      code:           b.code != null ? String(b.code).trim() : undefined,
      nameAr:         b.nameAr != null ? String(b.nameAr).trim() : undefined,
      nameEn:         b.nameEn ?? null,
      phone:          b.phone ?? null,
      email:          b.email ?? null,
      address:        b.address ?? null,
      branchId:       b.branchId ? Number(b.branchId) : null,
      region:         b.region ?? null,
      isActive:       b.isActive !== undefined ? !!b.isActive : undefined,
      commissionPct:  b.commissionPct != null ? String(b.commissionPct) : undefined,
      commissionType: b.commissionType === "collection" ? "collection"
                      : b.commissionType === "invoice" ? "invoice" : undefined,
      monthlyTarget:  b.monthlyTarget != null ? String(b.monthlyTarget) : undefined,
      accountId:      b.accountId ? Number(b.accountId) : null,
      notes:          b.notes ?? null,
      updatedAt:      new Date(),
    }).where(and(eq(salesRepsTable.id, id), eq(salesRepsTable.companyId, cid))).returning();

    if (!row) { res.status(404).json({ error: "المندوب غير موجود" }); return; }
    res.json(row);
  } catch (e: any) { res.status(500).json({ error: e.message }); }
});

router.delete("/:id", async (req, res) => {
  try {
    const cid = guard(req, res); if (!cid) return;
    const id = Number(req.params.id);

    // Refuse delete when the rep is referenced from invoices, customers, or
    // receipt vouchers — the user should deactivate instead so historical
    // commission history (incl. collection-based commissions) stays intact.
    const [{ n: invN }] = await db.select({ n: sql<number>`count(*)::int` })
      .from(salesInvoicesTable)
      .where(and(eq(salesInvoicesTable.companyId, cid), eq(salesInvoicesTable.salesRepId, id)));
    const [{ n: custN }] = await db.select({ n: sql<number>`count(*)::int` })
      .from(customersTable)
      .where(and(eq(customersTable.companyId, cid), eq(customersTable.salesRepId, id)));
    const [{ n: rcvN }] = await db.select({ n: sql<number>`count(*)::int` })
      .from(receiptVouchersTable)
      .where(and(eq(receiptVouchersTable.companyId, cid), eq(receiptVouchersTable.salesRepId, id)));
    if (invN > 0 || custN > 0 || rcvN > 0) {
      res.status(409).json({
        error: `لا يمكن حذف المندوب — مرتبط بـ ${invN} فاتورة و ${custN} عميل و ${rcvN} سند قبض. يمكنك تعطيله بدلاً من ذلك.`,
      });
      return;
    }

    await db.delete(salesRepsTable)
      .where(and(eq(salesRepsTable.id, id), eq(salesRepsTable.companyId, cid)));
    res.json({ ok: true });
  } catch (e: any) { res.status(500).json({ error: e.message }); }
});

// ─── VISITS ─────────────────────────────────────────────────────────────────
router.get("/:id/visits", async (req, res) => {
  try {
    const cid = getCid(req);
    const repId = Number(req.params.id);
    if (!cid) { res.json([]); return; }
    const rows = await db.select().from(salesRepVisitsTable)
      .where(and(eq(salesRepVisitsTable.companyId, cid), eq(salesRepVisitsTable.salesRepId, repId)))
      .orderBy(desc(salesRepVisitsTable.visitDate), desc(salesRepVisitsTable.id));
    res.json(rows);
  } catch (e: any) { res.status(500).json({ error: e.message }); }
});

router.post("/:id/visits", async (req, res) => {
  try {
    const cid = guard(req, res); if (!cid) return;
    const repId = Number(req.params.id);
    const b = req.body ?? {};
    if (!b.visitDate) { res.status(400).json({ error: "تاريخ الزيارة مطلوب" }); return; }

    const [row] = await db.insert(salesRepVisitsTable).values({
      companyId:    cid,
      salesRepId:   repId,
      customerId:   b.customerId ? Number(b.customerId) : null,
      visitDate:    String(b.visitDate),
      status:       ["planned","completed","cancelled"].includes(b.status) ? b.status : "completed",
      outcome:      ["none","interested","quotation_sent","deal_closed","no_interest","follow_up"].includes(b.outcome) ? b.outcome : "none",
      notes:        b.notes || null,
      followUpDate: b.followUpDate || null,
    }).returning();
    res.status(201).json(row);
  } catch (e: any) { res.status(500).json({ error: e.message }); }
});

router.put("/visits/:vid", async (req, res) => {
  try {
    const cid = guard(req, res); if (!cid) return;
    const vid = Number(req.params.vid);
    const b = req.body ?? {};
    const [row] = await db.update(salesRepVisitsTable).set({
      customerId:   b.customerId ? Number(b.customerId) : null,
      visitDate:    b.visitDate ? String(b.visitDate) : undefined,
      status:       ["planned","completed","cancelled"].includes(b.status) ? b.status : undefined,
      outcome:      ["none","interested","quotation_sent","deal_closed","no_interest","follow_up"].includes(b.outcome) ? b.outcome : undefined,
      notes:        b.notes ?? null,
      followUpDate: b.followUpDate ?? null,
      updatedAt:    new Date(),
    }).where(and(eq(salesRepVisitsTable.id, vid), eq(salesRepVisitsTable.companyId, cid))).returning();
    if (!row) { res.status(404).json({ error: "الزيارة غير موجودة" }); return; }
    res.json(row);
  } catch (e: any) { res.status(500).json({ error: e.message }); }
});

router.delete("/visits/:vid", async (req, res) => {
  try {
    const cid = guard(req, res); if (!cid) return;
    const vid = Number(req.params.vid);
    await db.delete(salesRepVisitsTable)
      .where(and(eq(salesRepVisitsTable.id, vid), eq(salesRepVisitsTable.companyId, cid)));
    res.json({ ok: true });
  } catch (e: any) { res.status(500).json({ error: e.message }); }
});

// ─── REPORTS ────────────────────────────────────────────────────────────────
// Sales + commissions per rep, optionally filtered by date range.
router.get("/reports/sales", async (req, res) => {
  try {
    const cid = getCid(req);
    if (!cid) { res.json([]); return; }
    const from = req.query.from ? String(req.query.from) : null;
    const to   = req.query.to   ? String(req.query.to)   : null;

    const reps = await db.select().from(salesRepsTable)
      .where(eq(salesRepsTable.companyId, cid));

    // Sum posted invoices grouped by salesRepId in the given date range.
    const conds = [
      eq(salesInvoicesTable.companyId, cid),
      eq(salesInvoicesTable.status, "posted"),
    ];
    if (from) conds.push(sql`${salesInvoicesTable.invoiceDate} >= ${from}`);
    if (to)   conds.push(sql`${salesInvoicesTable.invoiceDate} <= ${to}`);

    const sums = await db
      .select({
        salesRepId:       salesInvoicesTable.salesRepId,
        invoiceCount:     sql<number>`count(*)::int`,
        totalSales:       sql<string>`COALESCE(SUM(${salesInvoicesTable.totalAmount}), 0)`,
        totalCommission:  sql<string>`COALESCE(SUM(${salesInvoicesTable.commissionAmount}), 0)`,
      })
      .from(salesInvoicesTable)
      .where(and(...conds))
      .groupBy(salesInvoicesTable.salesRepId);

    // Posted receipts collected by each rep (only meaningful when commissionType=collection)
    const recvConds = [
      eq(receiptVouchersTable.companyId, cid),
      eq(receiptVouchersTable.status, "posted"),
    ];
    if (from) recvConds.push(sql`${receiptVouchersTable.date} >= ${from}`);
    if (to)   recvConds.push(sql`${receiptVouchersTable.date} <= ${to}`);
    const collections = await db
      .select({
        salesRepId: receiptVouchersTable.salesRepId,
        collected:  sql<string>`COALESCE(SUM(${receiptVouchersTable.amount}), 0)`,
      })
      .from(receiptVouchersTable)
      .where(and(...recvConds))
      .groupBy(receiptVouchersTable.salesRepId);

    const sumMap = new Map(sums.map(s => [s.salesRepId, s]));
    const colMap = new Map(collections.map(c => [c.salesRepId, c]));

    const out = reps.map(r => {
      const s = sumMap.get(r.id);
      const c = colMap.get(r.id);
      const totalSales      = Number(s?.totalSales      ?? 0);
      const totalCommission = Number(s?.totalCommission ?? 0);
      const collected       = Number(c?.collected       ?? 0);
      const target          = Number(r.monthlyTarget    ?? 0);
      // For collection-type reps, recompute commission from collections × pct
      const effectiveCommission = r.commissionType === "collection"
        ? collected * (Number(r.commissionPct) / 100)
        : totalCommission;
      return {
        salesRepId:       r.id,
        code:             r.code,
        nameAr:           r.nameAr,
        commissionPct:    Number(r.commissionPct),
        commissionType:   r.commissionType,
        monthlyTarget:    target,
        invoiceCount:     s?.invoiceCount ?? 0,
        totalSales,
        collected,
        commission:       effectiveCommission,
        targetAchievedPct: target > 0 ? Math.round((totalSales / target) * 100) : null,
      };
    });
    res.json(out);
  } catch (e: any) { res.status(500).json({ error: e.message }); }
});

// ─── AI PERFORMANCE ANALYSIS ─────────────────────────────────────────────────
// POST /api/sales-reps/:id/ai-analysis?companyId=X
// Aggregates last-90-days facts about the rep and asks Claude for an Arabic
// performance review with concrete recommendations. Returns markdown text.
router.post("/:id/ai-analysis", async (req, res) => {
  try {
    const cid = guard(req, res); if (!cid) return;
    const id = Number(req.params.id);

    const [rep] = await db.select().from(salesRepsTable)
      .where(and(eq(salesRepsTable.id, id), eq(salesRepsTable.companyId, cid)));
    if (!rep) { res.status(404).json({ error: "المندوب غير موجود" }); return; }

    // Window: last 90 days (date strings YYYY-MM-DD).
    const today = new Date();
    const since = new Date(today.getTime() - 90 * 86400_000).toISOString().slice(0, 10);
    const monthStart = `${today.toISOString().slice(0, 7)}-01`;

    // Posted invoices for this rep in the window.
    const invs = await db.select({
      id:               salesInvoicesTable.id,
      invoiceDate:      salesInvoicesTable.invoiceDate,
      customerId:       salesInvoicesTable.customerId,
      totalAmount:      salesInvoicesTable.totalAmount,
      commissionAmount: salesInvoicesTable.commissionAmount,
      status:           salesInvoicesTable.status,
    })
      .from(salesInvoicesTable)
      .where(and(
        eq(salesInvoicesTable.companyId, cid),
        eq(salesInvoicesTable.salesRepId, id),
        eq(salesInvoicesTable.status, "posted"),
        sql`${salesInvoicesTable.invoiceDate} >= ${since}`,
      ));

    let totalSales = 0, totalCommission = 0, mtdSales = 0;
    const byCustomer = new Map<number, number>();
    for (const inv of invs) {
      const t = Number(inv.totalAmount ?? 0);
      totalSales += t;
      totalCommission += Number(inv.commissionAmount ?? 0);
      if (inv.invoiceDate >= monthStart) mtdSales += t;
      if (inv.customerId != null) {
        byCustomer.set(inv.customerId, (byCustomer.get(inv.customerId) ?? 0) + t);
      }
    }

    // Top 5 customers by sales value.
    const topCustIds = [...byCustomer.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([cidc]) => cidc);
    const custRows = topCustIds.length
      ? await db.select({ id: customersTable.id, nameAr: customersTable.nameAr })
          .from(customersTable)
          .where(and(eq(customersTable.companyId, cid), inArray(customersTable.id, topCustIds)))
      : [];
    const topCustomers = topCustIds.map(cidc => ({
      name:  custRows.find(c => c.id === cidc)?.nameAr ?? `#${cidc}`,
      total: byCustomer.get(cidc) ?? 0,
    }));

    // Linked customers count (book size).
    const [{ n: bookSize }] = await db.select({ n: sql<number>`count(*)::int` })
      .from(customersTable)
      .where(and(eq(customersTable.companyId, cid), eq(customersTable.salesRepId, id)));

    // Recent visits (last 30 days, up to 30 entries).
    const since30 = new Date(today.getTime() - 30 * 86400_000).toISOString().slice(0, 10);
    const visits = await db.select()
      .from(salesRepVisitsTable)
      .where(and(
        eq(salesRepVisitsTable.companyId, cid),
        eq(salesRepVisitsTable.salesRepId, id),
        sql`${salesRepVisitsTable.visitDate} >= ${since30}`,
      ))
      .orderBy(desc(salesRepVisitsTable.visitDate))
      .limit(30);
    const visitsByOutcome = visits.reduce((acc, v) => {
      acc[v.outcome] = (acc[v.outcome] ?? 0) + 1; return acc;
    }, {} as Record<string, number>);

    const target = Number(rep.monthlyTarget ?? 0);
    const targetPct = target > 0 ? Math.round((mtdSales / target) * 100) : null;

    const facts = {
      rep: {
        name:           rep.nameAr,
        code:           rep.code,
        region:         rep.region,
        commissionPct:  Number(rep.commissionPct),
        commissionType: rep.commissionType,
        monthlyTarget:  target,
        isActive:       rep.isActive,
      },
      window: { since, today: today.toISOString().slice(0, 10), monthStart },
      sales: {
        invoiceCount90d:     invs.length,
        totalSales90d:       Number(totalSales.toFixed(2)),
        totalCommission90d:  Number(totalCommission.toFixed(2)),
        monthToDateSales:    Number(mtdSales.toFixed(2)),
        monthlyTarget:       target,
        targetAchievedPct:   targetPct,
        avgInvoiceValue:     invs.length ? Number((totalSales / invs.length).toFixed(2)) : 0,
      },
      bookSize,
      topCustomers,
      visits30d: {
        total:     visits.length,
        byOutcome: visitsByOutcome,
      },
    };

    if (!process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL || !process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY) {
      res.status(503).json({ error: "خدمة الذكاء الاصطناعي غير مهيّأة على الخادم." });
      return;
    }

    const client = new Anthropic({
      apiKey:  process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY,
      baseURL: process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL,
    });

    const prompt = `أنت محلل مبيعات خبير في شركة سعودية تستخدم نظام محاسبة عربي.
حلّل أداء مندوب المبيعات التالي بناءً على البيانات الموضوعية فقط، واكتب الردّ بالعربية الفصحى الواضحة وبتنسيق Markdown.

البيانات (JSON):
\`\`\`json
${JSON.stringify(facts, null, 2)}
\`\`\`

اكتب الردّ في الأقسام التالية فقط:
1. **ملخص الأداء** — فقرة قصيرة (سطرين-ثلاثة) تذكر المبيعات والعمولة وتحقيق الهدف.
2. **نقاط القوة** — قائمة 2-4 نقاط مرتكزة على البيانات.
3. **نقاط للتحسين** — قائمة 2-4 نقاط محددة (مثلاً اعتماد على عميل واحد، نقص زيارات، تحقيق هدف منخفض).
4. **توصيات عملية** — قائمة 3-5 إجراءات قابلة للتنفيذ خلال 30 يوماً.

قواعد:
- لا تخترع أرقاماً غير موجودة في البيانات.
- إذا كانت البيانات شحيحة (صفر فواتير أو صفر زيارات) صرّح بذلك واقترح خطوات لجمع بيانات.
- استخدم القيم بالريال السعودي (ر.س).`;

    const message = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 8192,
      messages: [{ role: "user", content: prompt }],
    });

    const block = message.content[0];
    const analysis = block && block.type === "text" ? block.text : "";

    res.json({ analysis, facts });
  } catch (e: any) {
    console.error("[sales-reps ai-analysis]", e);
    res.status(500).json({ error: e?.message ?? "فشل تحليل الأداء" });
  }
});

export default router;
