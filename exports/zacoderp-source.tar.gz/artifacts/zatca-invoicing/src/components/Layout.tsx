import React, { useEffect, useMemo, useState } from "react";
import { Link, useLocation } from "wouter";
import { useTranslation } from "react-i18next";
import {
  LayoutDashboard, Building2, FileText, Users, Settings,
  Bell, Menu, Truck, LogOut, ChevronDown, ChevronRight, ShieldCheck,
  Package, Clock, Settings2, Link2, SlidersHorizontal, Sliders, BarChart3,
  Warehouse, Ruler, ArrowRightLeft, ClipboardList, BookOpen, BarChart2,
  Tag, Layers, BookMarked, MapPin, Building2 as BranchIcon, DollarSign,
  TrendingUp, Scale, PieChart, ShoppingCart, CreditCard, RotateCcw, Banknote,
  Wallet, Landmark, ArrowDownCircle, ArrowUpCircle, ArrowLeftRight,
  Search, Home, HelpCircle, ChevronLeft,
  ShoppingBag, FileSignature, KeyRound, CalendarRange, Target, Undo2, ExternalLink, UserCog, Calculator,
  Activity, MonitorSmartphone, AlertTriangle, Sparkles, MessageSquare, Inbox,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useAuth } from "@/contexts/AuthContext";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { NotificationBell } from "@/components/NotificationBell";
import { SUPPORTED_LANGUAGES, normalizeLang } from "@/i18n";

// ─── Nav definitions ───────────────────────────────────────────────────────────
type NavDef = { nameKey: string; href: string; icon: any; exact?: boolean; permKey?: string };

const superAdminNav: NavDef[] = [
  { nameKey: "nav.dashboard",            href: "/",                         icon: LayoutDashboard, exact: true },
  { nameKey: "nav.registrationRequests", href: "/admin/requests",           icon: Clock },
  { nameKey: "nav.licenses",             href: "/admin/licenses",           icon: KeyRound },
  { nameKey: "nav.subscriptions",        href: "/admin/subscriptions",      icon: Package },
  { nameKey: "nav.plans",                href: "/admin/plans",              icon: Settings2 },
  { nameKey: "nav.menuPermissions",      href: "/admin/menu-permissions",   icon: SlidersHorizontal },
  { nameKey: "nav.orphanStock",          href: "/admin/orphan-stock",       icon: AlertTriangle },
  { nameKey: "nav.aiCompanyFix",         href: "/admin/ai-fix",             icon: Sparkles },
  { nameKey: "nav.supportInbox",         href: "/admin/support",            icon: Inbox },
  { nameKey: "nav.supportSettings",      href: "/admin/support-settings",   icon: MessageSquare },
  { nameKey: "nav.companies",            href: "/companies",                icon: Building2 },
  { nameKey: "nav.posMonitoring",        href: "/pos-monitoring",           icon: Activity },
];
const companyBusinessNav: NavDef[] = [
  { nameKey: "nav.posMonitoring", href: "/pos-monitoring",     icon: Activity, permKey: "pos" },
  { nameKey: "nav.posTerminals",  href: "/pos-terminals",      icon: MonitorSmartphone, permKey: "pos" },
  { nameKey: "nav.posSettings",   href: "/pos-settings",       icon: Settings, permKey: "pos" },
];
// HR submenu — sits under the "شؤون الموظفين" (HR) collapsible group.
const hrSubNav: NavDef[] = [
  { nameKey: "nav.hrEmployeesList", href: "/hr/employees",       icon: UserCog },
  { nameKey: "nav.hrContracts",     href: "/hr/contracts",       icon: FileSignature },
  { nameKey: "nav.hrAttendance",    href: "/hr/attendance",      icon: CalendarRange },
  { nameKey: "nav.hrLoans",         href: "/hr/loans",           icon: Wallet },
  { nameKey: "nav.hrPayroll",       href: "/hr/payroll",         icon: Banknote },
  { nameKey: "nav.hrEos",           href: "/hr/end-of-service",  icon: Scale },
  { nameKey: "nav.hrCalculators",   href: "/hr/calculators",     icon: Calculator },
  { nameKey: "nav.hrSettings",      href: "/hr/settings",        icon: Settings },
];
const dashboardSubNav: NavDef[] = [
  { nameKey: "nav.regions",         href: "/org/regions",         icon: MapPin     },
  { nameKey: "nav.branches",        href: "/org/branches",        icon: BranchIcon },
  { nameKey: "nav.zatcaLink",       href: "/zatca",               icon: Link2      },
  { nameKey: "nav.generalSettings", href: "/general-settings",    icon: Sliders    },
  { nameKey: "nav.users",           href: "/users",               icon: Users      },
  { nameKey: "nav.currencies",      href: "/settings/currencies", icon: DollarSign },
  { nameKey: "nav.accountingMappings", href: "/settings/accounting-mappings", icon: BookMarked },
  { nameKey: "nav.invoices",        href: "/invoices",            icon: FileText   },
  { nameKey: "nav.vatDeclaration",  href: "/vat-declaration",     icon: BarChart3  },
];

const purchasingSubNav: NavDef[] = [
  { nameKey: "nav.suppliers",            href: "/suppliers",                  icon: Truck        },
  { nameKey: "nav.supplierGroups",       href: "/purchasing/supplier-groups", icon: Users        },
  { nameKey: "nav.lc",                   href: "/purchasing/lc",              icon: CreditCard   },
  { nameKey: "nav.purchaseInvoices",     href: "/purchasing/invoices",        icon: ShoppingCart },
  { nameKey: "nav.purchaseReturns",      href: "/purchasing/returns",         icon: RotateCcw    },
  { nameKey: "nav.supplierSettlements",  href: "/purchasing/settlements",     icon: Banknote     },
];
const salesSubNav: NavDef[] = [
  { nameKey: "nav.customers",            href: "/customers",         icon: Users           },
  { nameKey: "nav.quotations",           href: "/sales/quotations",  icon: FileSignature   },
  { nameKey: "nav.salesInvoices",        href: "/sales/invoices",    icon: ShoppingBag     },
  { nameKey: "nav.salesReturns",         href: "/sales/returns",     icon: RotateCcw       },
  { nameKey: "nav.customerSettlements",  href: "/sales/settlements", icon: ArrowDownCircle },
  { nameKey: "nav.zatcaBridge",          href: "/zatca-bridge",      icon: Link2           },
  { nameKey: "nav.zatcaReport",          href: "/zatca-report",      icon: BarChart3       },
];
const companySystemNav: NavDef[] = [];

const accountingSubNav: NavDef[] = [
  { nameKey: "nav.chartOfAccounts", href: "/accounting/accounts",       icon: BookMarked    },
  { nameKey: "nav.costCenters",     href: "/accounting/cost-centers",   icon: Target        },
  { nameKey: "nav.fiscalPeriods",   href: "/accounting/fiscal-periods", icon: CalendarRange },
  { nameKey: "nav.journals",        href: "/accounting/journals",       icon: BookOpen      },
];
const reportsSubNav: NavDef[] = [
  { nameKey: "nav.accountStatement", href: "/accounting/reports/account-statement", icon: FileText   },
  { nameKey: "nav.trialBalance",     href: "/accounting/reports/trial-balance",     icon: Scale      },
  { nameKey: "nav.balanceSheet",     href: "/accounting/reports/balance-sheet",     icon: PieChart   },
  { nameKey: "nav.incomeStatement",  href: "/accounting/reports/income-statement",  icon: TrendingUp },
];
const cashSubNav: NavDef[] = [
  { nameKey: "nav.cashBoxes",        href: "/cash/boxes",            icon: Wallet           },
  { nameKey: "nav.banks",            href: "/cash/banks",            icon: Landmark         },
  { nameKey: "nav.receiptVouchers",  href: "/cash/receipt-vouchers", icon: ArrowDownCircle  },
  { nameKey: "nav.paymentVouchers",  href: "/cash/payment-vouchers", icon: ArrowUpCircle    },
  { nameKey: "nav.transfers",        href: "/cash/transfers",        icon: ArrowLeftRight   },
];

const inventoryHeader: NavDef = { nameKey: "nav.inventoryDashboard", href: "/inventory", icon: LayoutDashboard, exact: true };
const inventorySubNav: NavDef[] = [
  { nameKey: "nav.items",             href: "/inventory/items",            icon: Package           },
  { nameKey: "nav.itemGroups",        href: "/inventory/item-groups",      icon: Tag               },
  { nameKey: "nav.units",             href: "/inventory/units",            icon: Ruler             },
  { nameKey: "nav.warehouses",        href: "/inventory/warehouses",       icon: Warehouse         },
  { nameKey: "nav.warehouseGroups",   href: "/inventory/warehouse-groups", icon: Layers            },
  { nameKey: "nav.stockTransfers",    href: "/inventory/transfers",        icon: ArrowRightLeft    },
  { nameKey: "nav.stockAdjustments",  href: "/inventory/adjustments",      icon: SlidersHorizontal },
  { nameKey: "nav.stockCounts",       href: "/inventory/counts",           icon: ClipboardList     },
];

const inventoryReportsHeader: NavDef = { nameKey: "nav.allReports", href: "/inventory/reports", icon: LayoutDashboard, exact: true };
const inventoryReportsSubNav: NavDef[] = [
  { nameKey: "navExtra.stockBalance", href: "/inventory/reports/stock-balance", icon: BarChart2     },
  { nameKey: "navExtra.stockLedger",  href: "/inventory/reports/stock-ledger",  icon: BookOpen      },
  { nameKey: "navExtra.itemCard",     href: "/inventory/reports/item-card",     icon: ClipboardList },
  { nameKey: "navExtra.lowStock",     href: "/inventory/reports/low-stock",     icon: SlidersHorizontal },
  { nameKey: "navExtra.valuation",    href: "/inventory/reports/valuation",     icon: Wallet        },
  { nameKey: "navExtra.slowMoving",   href: "/inventory/reports/slow-moving",   icon: Layers        },
];

// ─── CashNavGroup ──────────────────────────────────────────────────────────────
function CashNavGroup({
  location, onNavigate, open, onToggle,
}: { location: string; onNavigate: () => void; open: boolean; onToggle: () => void }) {
  const { t } = useTranslation();
  const isOnCash = location.startsWith("/cash") && !location.startsWith("/cash/reports");
  return (
    <div>
      <button onClick={onToggle} className={cn("w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors", isOnCash && !open ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm" : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground")}>
        <Wallet className="h-4 w-4 shrink-0" />
        <span className="flex-1 text-start">{t("nav.cashGroup")}</span>
        {open ? <ChevronDown className="h-3.5 w-3.5 shrink-0 opacity-60" /> : <ChevronRight className="h-3.5 w-3.5 shrink-0 opacity-60" />}
      </button>
      {open && (
        <div className="mt-0.5 space-y-0.5 relative">
          <div className="absolute top-0 bottom-0 start-[26px] w-px bg-sidebar-border/60" />
          {cashSubNav.map(item => (
            <NavItem key={item.href} item={item} location={location} onClick={onNavigate} indent />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── CashReportsNavGroup ──────────────────────────────────────────────────────
const cashReportsSubNav: NavDef[] = [
  { nameKey: "navExtra.cashBalances",   href: "/cash/reports/cash-balances",      icon: FileText },
  { nameKey: "navExtra.bankBalances",   href: "/cash/reports/bank-balances",      icon: FileText },
  { nameKey: "navExtra.cashBoxStatement", href: "/cash/reports/cash-box-statement", icon: FileText },
  { nameKey: "navExtra.bankStatement",  href: "/cash/reports/bank-statement",     icon: FileText },
  { nameKey: "navExtra.dailySummary",   href: "/cash/reports/daily-summary",      icon: FileText },
  { nameKey: "navExtra.receiptsReport", href: "/cash/reports/receipts",           icon: FileText },
  { nameKey: "navExtra.paymentsReport", href: "/cash/reports/payments",           icon: FileText },
  { nameKey: "navExtra.transfersReport", href: "/cash/reports/transfers",         icon: FileText },
];
const cashReportsHeader: NavDef = { nameKey: "nav.allReports", href: "/cash/reports", icon: BarChart2 };

function CashReportsNavGroup({
  location, onNavigate, open, onToggle,
}: { location: string; onNavigate: () => void; open: boolean; onToggle: () => void }) {
  const { t } = useTranslation();
  const isOnReports = location.startsWith("/cash/reports");
  return (
    <div>
      <button
        onClick={onToggle}
        className={cn(
          "w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
          isOnReports && !open
            ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
            : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
        )}
      >
        <BarChart2 className="h-4 w-4 shrink-0" />
        <span className="flex-1 text-start">{t("nav.cashReports")}</span>
        {open
          ? <ChevronDown  className="h-3.5 w-3.5 shrink-0 opacity-60" />
          : <ChevronRight className="h-3.5 w-3.5 shrink-0 opacity-60" />}
      </button>
      {open && (
        <div className="mt-0.5 space-y-0.5 relative">
          <div className="absolute top-0 bottom-0 start-[26px] w-px bg-sidebar-border/60" />
          <NavItem item={cashReportsHeader} location={location} onClick={onNavigate} indent />
          {cashReportsSubNav.map(item => (
            <NavItem key={item.href} item={item} location={location} onClick={onNavigate} indent />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Helpers ───────────────────────────────────────────────────────────────────
const DEFAULT_PERMS: Record<string, boolean> = {
  dashboard: true, invoices: true, customers: true, suppliers: true,
  zatca: true, reports: true, inventory: true,
};
function parseMenuPerms(raw: string | null | undefined): Record<string, boolean> {
  try { return { ...DEFAULT_PERMS, ...JSON.parse(raw ?? "{}") }; }
  catch { return { ...DEFAULT_PERMS }; }
}
const PLAN_KEYS: Record<string, string> = {
  starter: "plans.starter", professional: "plans.professional", enterprise: "plans.enterprise",
};

// ─── NavItem (stable, top-level component) ─────────────────────────────────────
function NavItem({
  item, location, onClick, indent = false,
}: {
  item: NavDef;
  location: string;
  onClick?: () => void;
  indent?: boolean;
}) {
  const { t } = useTranslation();
  const isActive = item.exact
    ? location === item.href
    : location.startsWith(item.href) && item.href !== "/";
  return (
    <div className={cn(
      "flex items-center rounded-lg pe-1 transition-colors group",
      isActive
        ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
        : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
    )}>
      <Link href={item.href} className="block flex-1 min-w-0" onClick={onClick}>
        <span className={cn(
          "flex items-center gap-3 px-3 py-2 text-sm font-medium",
          indent && "ps-8",
        )}>
          <item.icon className="h-4 w-4 shrink-0" />
          {t(item.nameKey)}
        </span>
      </Link>
      <a
        href={item.href}
        target="_blank"
        rel="noopener noreferrer"
        title={t("nav.openInNewTab", "فتح في تبويب جديد")}
        className={cn(
          "p-1.5 rounded-md opacity-60 hover:opacity-100 hover:bg-black/10 dark:hover:bg-white/10 transition",
          isActive ? "text-sidebar-primary-foreground" : "text-muted-foreground"
        )}
        onClick={(e) => e.stopPropagation()}
      >
        <ExternalLink className="h-3.5 w-3.5" />
      </a>
    </div>
  );
}

// ─── PurchasingNavGroup ────────────────────────────────────────────────────────
function PurchasingNavGroup({
  location, onNavigate, open, onToggle,
}: {
  location: string;
  onNavigate: () => void;
  open: boolean;
  onToggle: () => void;
}) {
  const { t } = useTranslation();
  const isOnPurchasing = ((location.startsWith("/purchasing") && !location.startsWith("/purchasing/reports")) || location.startsWith("/suppliers"));
  return (
    <div>
      <button
        onClick={onToggle}
        className={cn(
          "w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
          isOnPurchasing && !open
            ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
            : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
        )}
      >
        <ShoppingCart className="h-4 w-4 shrink-0" />
        <span className="flex-1 text-start">{t("nav.purchasingGroup")}</span>
        {open
          ? <ChevronDown  className="h-3.5 w-3.5 shrink-0 opacity-60" />
          : <ChevronRight className="h-3.5 w-3.5 shrink-0 opacity-60" />
        }
      </button>
      {open && (
        <div className="mt-0.5 space-y-0.5 relative">
          <div className="absolute top-0 bottom-0 start-[26px] w-px bg-sidebar-border/60" />
          {purchasingSubNav.map(item => (
            <NavItem key={item.href} item={item} location={location} onClick={onNavigate} indent />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── SalesNavGroup ─────────────────────────────────────────────────────────────
function SalesNavGroup({
  location, onNavigate, open, onToggle,
}: {
  location: string;
  onNavigate: () => void;
  open: boolean;
  onToggle: () => void;
}) {
  const { t } = useTranslation();
  const isOnSales = (location.startsWith("/sales") && !location.startsWith("/sales/reports")) || location.startsWith("/customers");
  return (
    <div>
      <button
        onClick={onToggle}
        className={cn(
          "w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
          isOnSales && !open
            ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
            : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
        )}
      >
        <ShoppingBag className="h-4 w-4 shrink-0" />
        <span className="flex-1 text-start">{t("nav.salesGroup")}</span>
        {open
          ? <ChevronDown  className="h-3.5 w-3.5 shrink-0 opacity-60" />
          : <ChevronRight className="h-3.5 w-3.5 shrink-0 opacity-60" />
        }
      </button>
      {open && (
        <div className="mt-0.5 space-y-0.5 relative">
          <div className="absolute top-0 bottom-0 start-[26px] w-px bg-sidebar-border/60" />
          {salesSubNav.map(item => (
            <NavItem key={item.href} item={item} location={location} onClick={onNavigate} indent />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── SalesReportsNavGroup ─────────────────────────────────────────────────────
const salesReportsSubNav: NavDef[] = [
  { nameKey: "navExtra.customerStatement",  href: "/sales/reports/customer-statement", icon: FileText },
  { nameKey: "navExtra.customerBalances",   href: "/sales/reports/customer-balances",  icon: FileText },
  { nameKey: "navExtra.salesAging",         href: "/sales/reports/aging",              icon: FileText },
  { nameKey: "navExtra.salesByCustomer",    href: "/sales/reports/sales-by-customer",  icon: FileText },
  { nameKey: "navExtra.salesByItem",        href: "/sales/reports/sales-by-item",      icon: FileText },
  { nameKey: "navExtra.salesByPeriod",      href: "/sales/reports/sales-by-period",    icon: FileText },
  { nameKey: "navExtra.topCustomers",       href: "/sales/reports/top-customers",      icon: FileText },
  { nameKey: "navExtra.salesReturnsReport", href: "/sales/reports/returns",            icon: FileText },
];
const salesReportsHeader: NavDef = { nameKey: "nav.allReports", href: "/sales/reports", icon: BarChart2 };

function SalesReportsNavGroup({
  location, onNavigate, open, onToggle,
}: {
  location: string;
  onNavigate: () => void;
  open: boolean;
  onToggle: () => void;
}) {
  const { t } = useTranslation();
  const isOnReports = location.startsWith("/sales/reports");
  return (
    <div>
      <button
        onClick={onToggle}
        className={cn(
          "w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
          isOnReports && !open
            ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
            : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
        )}
      >
        <BarChart2 className="h-4 w-4 shrink-0" />
        <span className="flex-1 text-start">{t("navExtra.salesReportsGroup")}</span>
        {open
          ? <ChevronDown  className="h-3.5 w-3.5 shrink-0 opacity-60" />
          : <ChevronRight className="h-3.5 w-3.5 shrink-0 opacity-60" />}
      </button>
      {open && (
        <div className="mt-0.5 space-y-0.5 relative">
          <div className="absolute top-0 bottom-0 start-[26px] w-px bg-sidebar-border/60" />
          <NavItem item={salesReportsHeader} location={location} onClick={onNavigate} indent />
          {salesReportsSubNav.map(item => (
            <NavItem key={item.href} item={item} location={location} onClick={onNavigate} indent />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── PurchasingReportsNavGroup ────────────────────────────────────────────────
const purchasingReportsSubNav: NavDef[] = [
  { nameKey: "navExtra.supplierStatement",      href: "/purchasing/reports/supplier-statement",   icon: FileText },
  { nameKey: "navExtra.supplierBalances",       href: "/purchasing/reports/supplier-balances",    icon: FileText },
  { nameKey: "navExtra.purchaseAging",          href: "/purchasing/reports/aging",                icon: FileText },
  { nameKey: "navExtra.purchasesBySupplier",    href: "/purchasing/reports/purchases-by-supplier", icon: FileText },
  { nameKey: "navExtra.purchasesByItem",        href: "/purchasing/reports/purchases-by-item",    icon: FileText },
  { nameKey: "navExtra.purchasesByPeriod",      href: "/purchasing/reports/purchases-by-period",  icon: FileText },
  { nameKey: "navExtra.topSuppliers",           href: "/purchasing/reports/top-suppliers",        icon: FileText },
  { nameKey: "navExtra.purchaseReturnsReport",  href: "/purchasing/reports/returns",              icon: FileText },
];
const purchasingReportsHeader: NavDef = { nameKey: "nav.allReports", href: "/purchasing/reports", icon: BarChart2 };

function PurchasingReportsNavGroup({
  location, onNavigate, open, onToggle,
}: {
  location: string;
  onNavigate: () => void;
  open: boolean;
  onToggle: () => void;
}) {
  const { t } = useTranslation();
  const isOnReports = location.startsWith("/purchasing/reports");
  return (
    <div>
      <button
        onClick={onToggle}
        className={cn(
          "w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
          isOnReports && !open
            ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
            : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
        )}
      >
        <BarChart2 className="h-4 w-4 shrink-0" />
        <span className="flex-1 text-start">{t("navExtra.purchaseReportsGroup")}</span>
        {open
          ? <ChevronDown  className="h-3.5 w-3.5 shrink-0 opacity-60" />
          : <ChevronRight className="h-3.5 w-3.5 shrink-0 opacity-60" />}
      </button>
      {open && (
        <div className="mt-0.5 space-y-0.5 relative">
          <div className="absolute top-0 bottom-0 start-[26px] w-px bg-sidebar-border/60" />
          <NavItem item={purchasingReportsHeader} location={location} onClick={onNavigate} indent />
          {purchasingReportsSubNav.map(item => (
            <NavItem key={item.href} item={item} location={location} onClick={onNavigate} indent />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── InventoryNavGroup (stable, top-level component) ──────────────────────────
function InventoryNavGroup({
  location, onNavigate, open, onToggle,
}: {
  location: string;
  onNavigate: () => void;
  open: boolean;
  onToggle: () => void;
}) {
  const { t } = useTranslation();
  const isOnInventory = location.startsWith("/inventory") && !location.startsWith("/inventory/reports");
  return (
    <div>
      {/* Toggle button */}
      <button
        onClick={onToggle}
        className={cn(
          "w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
          isOnInventory && !open
            ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
            : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
        )}
      >
        <Warehouse className="h-4 w-4 shrink-0" />
        <span className="flex-1 text-start">{t("navExtra.inventoryModule")}</span>
        {open
          ? <ChevronDown  className="h-3.5 w-3.5 shrink-0 opacity-60" />
          : <ChevronRight className="h-3.5 w-3.5 shrink-0 opacity-60" />
        }
      </button>

      {/* Sub-items */}
      {open && (
        <div className="mt-0.5 space-y-0.5 relative">
          <div className="absolute top-0 bottom-0 start-[26px] w-px bg-sidebar-border/60" />
          <NavItem item={inventoryHeader} location={location} onClick={onNavigate} indent />
          {inventorySubNav.map(item => (
            <NavItem key={item.href} item={item} location={location} onClick={onNavigate} indent />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── InventoryReportsNavGroup ─────────────────────────────────────────────────
function InventoryReportsNavGroup({
  location, onNavigate, open, onToggle,
}: {
  location: string;
  onNavigate: () => void;
  open: boolean;
  onToggle: () => void;
}) {
  const { t } = useTranslation();
  const isOnReports = location.startsWith("/inventory/reports");
  return (
    <div>
      <button
        onClick={onToggle}
        className={cn(
          "w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
          isOnReports && !open
            ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
            : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
        )}
      >
        <BarChart2 className="h-4 w-4 shrink-0" />
        <span className="flex-1 text-start">{t("nav.inventoryReports")}</span>
        {open
          ? <ChevronDown  className="h-3.5 w-3.5 shrink-0 opacity-60" />
          : <ChevronRight className="h-3.5 w-3.5 shrink-0 opacity-60" />}
      </button>
      {open && (
        <div className="mt-0.5 space-y-0.5 relative">
          <div className="absolute top-0 bottom-0 start-[26px] w-px bg-sidebar-border/60" />
          <NavItem item={inventoryReportsHeader} location={location} onClick={onNavigate} indent />
          {inventoryReportsSubNav.map(item => (
            <NavItem key={item.href} item={item} location={location} onClick={onNavigate} indent />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── ReportsNavGroup ───────────────────────────────────────────────────────────
function ReportsNavGroup({
  location, onNavigate, open, onToggle,
}: {
  location: string;
  onNavigate: () => void;
  open: boolean;
  onToggle: () => void;
}) {
  const { t } = useTranslation();
  const isOnReports = location.startsWith("/accounting/reports");
  return (
    <div>
      <button
        onClick={onToggle}
        className={cn(
          "w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
          isOnReports && !open
            ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
            : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
        )}
      >
        <BarChart2 className="h-4 w-4 shrink-0" />
        <span className="flex-1 text-start">{t("navExtra.accountingReports")}</span>
        {open
          ? <ChevronDown  className="h-3.5 w-3.5 shrink-0 opacity-60" />
          : <ChevronRight className="h-3.5 w-3.5 shrink-0 opacity-60" />
        }
      </button>
      {open && (
        <div className="mt-0.5 space-y-0.5 relative">
          <div className="absolute top-0 bottom-0 start-[26px] w-px bg-sidebar-border/60" />
          {reportsSubNav.map(item => (
            <NavItem key={item.href} item={item} location={location} onClick={onNavigate} indent />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── DashboardNavGroup ─────────────────────────────────────────────────────────
function DashboardNavGroup({
  location, onNavigate, open, onToggle,
}: {
  location: string;
  onNavigate: () => void;
  open: boolean;
  onToggle: () => void;
}) {
  const { t } = useTranslation();
  const isActive = location === "/";
  const isOnSub  = dashboardSubNav.some(i => location.startsWith(i.href) && i.href !== "/");
  return (
    <div>
      <div className={cn(
        "flex items-center rounded-lg transition-colors",
        (isActive || (isOnSub && !open))
          ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
          : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
      )}>
        <Link href="/" className="flex items-center gap-3 flex-1 px-3 py-2 text-sm font-medium" onClick={onNavigate}>
          <LayoutDashboard className="h-4 w-4 shrink-0" />
          <span>{t("nav.dashboard")}</span>
        </Link>
        <a
          href="/"
          target="_blank"
          rel="noopener noreferrer"
          title={t("nav.openInNewTab", "فتح في تبويب جديد")}
          onClick={(e) => e.stopPropagation()}
          className="px-2 py-2 rounded-md opacity-60 hover:opacity-100 hover:bg-black/10 dark:hover:bg-white/10"
        >
          <ExternalLink className="h-3.5 w-3.5" />
        </a>
        <button onClick={onToggle} className="px-2 py-2 rounded-lg" title={t("nav.dashboard")}>
          {open
            ? <ChevronDown  className="h-3.5 w-3.5 shrink-0 opacity-60" />
            : <ChevronRight className="h-3.5 w-3.5 shrink-0 opacity-60" />
          }
        </button>
      </div>
      {open && (
        <div className="mt-0.5 space-y-0.5 relative">
          <div className="absolute top-0 bottom-0 start-[26px] w-px bg-sidebar-border/60" />
          <AutoPostingToggle />
          {dashboardSubNav.map(item => (
            <NavItem key={item.href} item={item} location={location} onClick={onNavigate} indent />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── AutoPostingToggle ─────────────────────────────────────────────────────────
// System-wide checkbox controlling whether invoices are auto-posted after save.
function AutoPostingToggle() {
  const { user, setUser } = useAuth() as any;
  const cid = user?.company?.id ?? user?.companyId;
  const enabled = user?.company?.autoPostingEnabled !== false;
  const [saving, setSaving] = useState(false);

  async function toggle(next: boolean) {
    if (!cid || saving) return;
    setSaving(true);
    try {
      const token = localStorage.getItem("zatca_token");
      const API = import.meta.env.BASE_URL.replace(/\/$/, "");
      const res = await fetch(`${API}/api/companies/${cid}/general-settings`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ autoPostingEnabled: next }),
      });
      if (res.ok) {
        const data = await res.json();
        if (setUser) {
          setUser((u: any) => u ? { ...u, company: { ...u.company, autoPostingEnabled: data.autoPostingEnabled } } : u);
        }
      }
    } finally { setSaving(false); }
  }

  return (
    <label
      className="ms-[42px] me-2 my-1 flex items-center gap-2 text-[12px] text-sidebar-foreground/80 hover:text-sidebar-foreground cursor-pointer select-none"
      title={enabled ? "الترحيل المحاسبي يتم تلقائياً بعد حفظ الفواتير" : "الترحيل المحاسبي يدوي — يجب الضغط على زر الترحيل"}
    >
      <input
        type="checkbox"
        className="h-3.5 w-3.5 accent-sidebar-primary"
        checked={enabled}
        disabled={saving || !cid}
        onChange={(e) => toggle(e.target.checked)}
      />
      <span>{enabled ? "ترحيل تلقائي" : "ترحيل يدوي"}</span>
    </label>
  );
}

// ─── AccountingNavGroup ───────────────────────────────────────────────────────
function AccountingNavGroup({
  location, onNavigate, open, onToggle,
}: { location: string; onNavigate: () => void; open: boolean; onToggle: () => void }) {
  const { t } = useTranslation();
  const isOnSub = accountingSubNav.some(i => location.startsWith(i.href));
  return (
    <div>
      <button onClick={onToggle} className={cn(
        "w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
        isOnSub && !open
          ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
          : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
      )}>
        <BookMarked className="h-4 w-4 shrink-0" />
        <span className="flex-1 text-start">{t("nav.accountingGroup")}</span>
        {open
          ? <ChevronDown  className="h-3.5 w-3.5 shrink-0 opacity-60" />
          : <ChevronRight className="h-3.5 w-3.5 shrink-0 opacity-60" />}
      </button>
      {open && (
        <div className="mt-0.5 space-y-0.5 relative">
          <div className="absolute top-0 bottom-0 start-[26px] w-px bg-sidebar-border/60" />
          {accountingSubNav.map(item => (
            <NavItem key={item.href} item={item} location={location} onClick={onNavigate} indent />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── HrNavGroup ───────────────────────────────────────────────────────────────
function HrNavGroup({
  location, onNavigate, open, onToggle,
}: { location: string; onNavigate: () => void; open: boolean; onToggle: () => void }) {
  const { t } = useTranslation();
  const isOnSub = hrSubNav.some(i => location.startsWith(i.href));
  return (
    <div>
      <button onClick={onToggle} className={cn(
        "w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
        isOnSub && !open
          ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
          : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
      )}>
        <UserCog className="h-4 w-4 shrink-0" />
        <span className="flex-1 text-start">{t("nav.hrEmployees")}</span>
        {open
          ? <ChevronDown  className="h-3.5 w-3.5 shrink-0 opacity-60" />
          : <ChevronRight className="h-3.5 w-3.5 shrink-0 opacity-60" />}
      </button>
      {open && (
        <div className="mt-0.5 space-y-0.5 relative">
          <div className="absolute top-0 bottom-0 start-[26px] w-px bg-sidebar-border/60" />
          {hrSubNav.map(item => (
            <NavItem key={item.href} item={item} location={location} onClick={onNavigate} indent />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── SidebarInner (stable, top-level component) ───────────────────────────────
// All state that needs to persist lives in Layout and is passed as props here.
function SidebarInner({
  location,
  isSuperAdmin,
  user,
  menuPerms,
  dashboardOpen,
  onDashboardToggle,
  inventoryOpen,
  onInventoryToggle,
  invReportsOpen,
  onInvReportsToggle,
  reportsOpen,
  onReportsToggle,
  purchasingOpen,
  onPurchasingToggle,
  purchasingReportsOpen,
  onPurchasingReportsToggle,
  salesOpen,
  onSalesToggle,
  salesReportsOpen,
  onSalesReportsToggle,
  cashOpen,
  onCashToggle,
  cashReportsOpen,
  onCashReportsToggle,
  accountingOpen,
  onAccountingToggle,
  hrOpen,
  onHrToggle,
  onNavigate,
  onLogout,
}: {
  location: string;
  isSuperAdmin: boolean;
  user: any;
  menuPerms: Record<string, boolean>;
  dashboardOpen: boolean;
  onDashboardToggle: () => void;
  inventoryOpen: boolean;
  onInventoryToggle: () => void;
  invReportsOpen: boolean;
  onInvReportsToggle: () => void;
  reportsOpen: boolean;
  onReportsToggle: () => void;
  purchasingOpen: boolean;
  onPurchasingToggle: () => void;
  purchasingReportsOpen: boolean;
  onPurchasingReportsToggle: () => void;
  salesOpen: boolean;
  onSalesToggle: () => void;
  salesReportsOpen: boolean;
  onSalesReportsToggle: () => void;
  cashOpen: boolean;
  onCashToggle: () => void;
  cashReportsOpen: boolean;
  onCashReportsToggle: () => void;
  accountingOpen: boolean;
  onAccountingToggle: () => void;
  hrOpen: boolean;
  onHrToggle: () => void;
  onNavigate: () => void;
  onLogout: () => void;
}) {
  const { t } = useTranslation();
  const filteredBusiness = companyBusinessNav.filter(i => !i.permKey || menuPerms[i.permKey] !== false);
  const filteredSystem   = companySystemNav.filter(i => !i.permKey || menuPerms[i.permKey] !== false);

  const planColor =
    user?.subscription?.plan === "starter"      ? "text-blue-700 bg-blue-50 border-blue-200" :
    user?.subscription?.plan === "professional" ? "text-primary bg-primary/10 border-primary/20" :
    user?.subscription?.plan === "enterprise"   ? "text-amber-700 bg-amber-50 border-amber-200" :
    "text-muted-foreground bg-muted border-border";

  return (
    <>
      {/* Logo */}
      <div className="flex h-16 shrink-0 items-center justify-between border-b border-sidebar-border px-4">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground font-bold text-sm shadow">Z</div>
          <div>
            <p className="text-sm font-bold text-sidebar-foreground leading-tight">{t("auth.appName")}</p>
            <p className="text-[10px] text-sidebar-foreground/50 leading-tight">ZATCA e-Invoicing</p>
          </div>
        </div>
        <div className="hidden md:flex items-center gap-1 text-[10px] text-green-700 bg-green-50 border border-green-200 rounded-full px-2 py-0.5">
          <ShieldCheck className="h-2.5 w-2.5" /><span>ZATCA</span>
        </div>
      </div>

      {/* Context badge */}
      {isSuperAdmin ? (
        <div className="mx-3 mt-3 mb-1 rounded-lg border bg-purple-50 border-purple-200 px-3 py-2.5">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-3.5 w-3.5 text-purple-600 shrink-0" />
            <span className="text-xs font-semibold text-purple-800">{t("topbar.superAdminPanel")}</span>
          </div>
          <p className="text-[10px] text-purple-600 mt-0.5">{t("topbar.superAdminSub")}</p>
        </div>
      ) : user?.company ? (
        <div className="mx-3 mt-3 mb-1 rounded-lg border bg-sidebar-accent/40 px-3 py-2.5">
          <div className="flex items-center gap-2 mb-0.5">
            <Building2 className="h-3.5 w-3.5 text-sidebar-foreground/60 shrink-0" />
            <span className="text-xs font-semibold text-sidebar-foreground truncate">{user.company.nameAr}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-mono text-sidebar-foreground/50 truncate">{user.company.vatNumber}</span>
            {user.subscription?.plan && (
              <span className={cn("text-[10px] border rounded-full px-1.5 py-0 font-medium shrink-0", planColor)}>
                {PLAN_KEYS[user.subscription.plan] ? t(PLAN_KEYS[user.subscription.plan]) : user.subscription.plan}
              </span>
            )}
          </div>
        </div>
      ) : null}

      {/* Navigation */}
      <nav className="flex-1 px-3 py-2 space-y-4 overflow-y-auto">
        {isSuperAdmin ? (
          <div className="space-y-0.5">
            {superAdminNav.map(item => (
              <NavItem key={item.href} item={item} location={location} onClick={onNavigate} />
            ))}
          </div>
        ) : (
          <>
            {menuPerms.dashboard !== false && (
              <div className="space-y-0.5">
                <DashboardNavGroup
                  location={location}
                  onNavigate={onNavigate}
                  open={dashboardOpen}
                  onToggle={onDashboardToggle}
                />
              </div>
            )}

            {menuPerms.inventory !== false && (
              <div className="space-y-0.5">
                <InventoryNavGroup
                  location={location}
                  onNavigate={onNavigate}
                  open={inventoryOpen}
                  onToggle={onInventoryToggle}
                />
              </div>
            )}

            {menuPerms.inventory !== false && (
              <div className="space-y-0.5">
                <InventoryReportsNavGroup
                  location={location}
                  onNavigate={onNavigate}
                  open={invReportsOpen}
                  onToggle={onInvReportsToggle}
                />
              </div>
            )}

            <div className="space-y-0.5">
              <SalesNavGroup
                location={location}
                onNavigate={onNavigate}
                open={salesOpen}
                onToggle={onSalesToggle}
              />
            </div>

            <div className="space-y-0.5">
              <SalesReportsNavGroup
                location={location}
                onNavigate={onNavigate}
                open={salesReportsOpen}
                onToggle={onSalesReportsToggle}
              />
            </div>

            <div className="space-y-0.5">
              <PurchasingNavGroup
                location={location}
                onNavigate={onNavigate}
                open={purchasingOpen}
                onToggle={onPurchasingToggle}
              />
            </div>

            <div className="space-y-0.5">
              <PurchasingReportsNavGroup
                location={location}
                onNavigate={onNavigate}
                open={purchasingReportsOpen}
                onToggle={onPurchasingReportsToggle}
              />
            </div>

            <div className="space-y-0.5">
              <CashNavGroup
                location={location}
                onNavigate={onNavigate}
                open={cashOpen}
                onToggle={onCashToggle}
              />
            </div>

            <div className="space-y-0.5">
              <CashReportsNavGroup
                location={location}
                onNavigate={onNavigate}
                open={cashReportsOpen}
                onToggle={onCashReportsToggle}
              />
            </div>

            <div className="space-y-0.5">
              <AccountingNavGroup
                location={location}
                onNavigate={onNavigate}
                open={accountingOpen}
                onToggle={onAccountingToggle}
              />
            </div>

            <div className="space-y-0.5">
              <HrNavGroup
                location={location}
                onNavigate={onNavigate}
                open={hrOpen}
                onToggle={onHrToggle}
              />
            </div>

            <div className="space-y-0.5">
              <ReportsNavGroup
                location={location}
                onNavigate={onNavigate}
                open={reportsOpen}
                onToggle={onReportsToggle}
              />
            </div>

            {filteredBusiness.length > 0 && (
              <div className="space-y-0.5">
                {filteredBusiness.map(item => (
                  <NavItem key={item.href} item={item} location={location} onClick={onNavigate} />
                ))}
              </div>
            )}

            {filteredSystem.length > 0 && (
              <div className="space-y-0.5">
                {filteredSystem.map(item => (
                  <NavItem key={item.href} item={item} location={location} onClick={onNavigate} />
                ))}
              </div>
            )}
          </>
        )}
      </nav>

      {/* User footer */}
      <div className="border-t border-sidebar-border p-3">
        {!isSuperAdmin && user?.subscription && (
          <div className="mb-2 flex items-center gap-2 px-2 py-1.5 rounded-md bg-sidebar-accent/30 text-xs text-sidebar-foreground/60">
            <Package className="h-3 w-3 shrink-0" />
            <span>{t("topbar.expires")}: {user.subscription.endDate ? new Date(user.subscription.endDate).toLocaleDateString() : "—"}</span>
          </div>
        )}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex w-full items-center gap-3 rounded-lg px-2 py-2 hover:bg-sidebar-accent transition-colors text-start">
              <Avatar className="h-8 w-8 shrink-0">
                <AvatarFallback className={cn(
                  "text-xs font-bold",
                  isSuperAdmin ? "bg-purple-100 text-purple-700" : "bg-primary text-primary-foreground"
                )}>
                  {user?.username?.[0]?.toUpperCase() ?? "م"}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0 text-start">
                <p className="text-sm font-medium text-sidebar-foreground truncate">{user?.username ?? t("topbar.user")}</p>
                <p className="text-xs text-sidebar-foreground/50 truncate">
                  {isSuperAdmin ? t("topbar.superAdmin") : user?.role === "admin" ? t("topbar.manager") : t("topbar.user")}
                </p>
              </div>
              <ChevronDown className="h-3.5 w-3.5 text-sidebar-foreground/40 shrink-0" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" side="top" className="w-52">
            <DropdownMenuLabel className="font-normal">
              <div>
                <p className="text-sm font-medium">{user?.username}</p>
                <p className="text-xs text-muted-foreground">
                  {isSuperAdmin ? t("topbar.superAdmin") : user?.role === "admin" ? t("topbar.companyManager") : t("topbar.user")}
                </p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild className="gap-2 cursor-pointer">
              <Link href="/settings">
                <Settings className="h-4 w-4" />{t("topbar.accountSettings")}
              </Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={onLogout} className="text-destructive focus:text-destructive gap-2">
              <LogOut className="h-4 w-4" />{t("topbar.logout")}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </>
  );
}

// ─── Breadcrumb Resolver ──────────────────────────────────────────────────────
// Build a complete map of href → { label, parent } from all nav definitions
type CrumbInfo = { label: string; parent?: string };
const ROUTE_MAP: Record<string, CrumbInfo> = (() => {
  const map: Record<string, CrumbInfo> = {
    "/":                              { label: "nav.dashboard" },
    "/companies":                     { label: "nav.companies" },
    "/customers":                     { label: "nav.customers" },
    "/customers/new":                 { label: "navExtra.newCustomer",       parent: "/customers" },
    "/suppliers/new":                 { label: "navExtra.newSupplier",       parent: "/suppliers" },
    "/invoices/new":                  { label: "navExtra.newInvoice",        parent: "/invoices" },
    "/settings":                      { label: "nav.settings" },
    "/admin/requests":                { label: "nav.registrationRequests" },
    "/admin/licenses":                { label: "nav.licenses" },
    "/admin/subscriptions":           { label: "nav.subscriptions" },
    "/admin/plans":                   { label: "nav.plans" },
    "/admin/menu-permissions":        { label: "nav.menuPermissions" },
    "/inventory":                     { label: "navExtra.inventoryRoot" },
    "/cash":                          { label: "nav.cashGroup" },
    "/cash/reports":                  { label: "nav.cashReports", parent: "/cash" },
    "/purchasing":                    { label: "nav.purchasingGroup" },
    "/sales":                         { label: "nav.salesGroup" },
    "/sales/invoices/new":            { label: "navExtra.newSalesInvoice", parent: "/sales/invoices" },
    "/sales/quotations/new":          { label: "navExtra.newQuotation",    parent: "/sales/quotations" },
    "/sales/reports":                 { label: "navExtra.salesReportsGroup", parent: "/sales" },
    "/purchasing/reports":            { label: "navExtra.purchaseReportsGroup", parent: "/purchasing" },
    "/inventory/reports":             { label: "nav.inventoryReports", parent: "/inventory" },
    "/accounting":                    { label: "navExtra.accountingRoot" },
    "/accounting/fiscal-periods":     { label: "nav.fiscalPeriods", parent: "/accounting" },
    "/accounting/reports":            { label: "navExtra.accountingReports", parent: "/accounting" },
    "/org":                           { label: "navExtra.orgRoot" },
  };
  const all = [
    ...dashboardSubNav,
    ...purchasingSubNav.map(i => ({ ...i, parent: "/purchasing" })),
    ...salesSubNav.map(i => ({ ...i, parent: "/sales" })),
    ...companySystemNav.map(i => ({ ...i, parent: "/accounting" })),
    ...reportsSubNav.map(i => ({ ...i, parent: "/accounting/reports" })),
    ...cashSubNav.map(i => ({ ...i, parent: "/cash" })),
    ...cashReportsSubNav.map(i => ({ ...i, parent: "/cash/reports" })),
    salesReportsHeader,
    ...salesReportsSubNav.map(i => ({ ...i, parent: "/sales/reports" })),
    purchasingReportsHeader,
    ...purchasingReportsSubNav.map(i => ({ ...i, parent: "/purchasing/reports" })),
    inventoryHeader,
    ...inventorySubNav.map(i => ({ ...i, parent: "/inventory" })),
    inventoryReportsHeader,
    ...inventoryReportsSubNav.map(i => ({ ...i, parent: "/inventory/reports" })),
    ...companyBusinessNav,
    ...hrSubNav,
  ];
  for (const item of all) {
    map[item.href] = {
      label: (item as any).nameKey ?? (item as any).name ?? "",
      parent: (item as any).parent,
    };
  }
  return map;
})();

function getBreadcrumbs(location: string, t: (k: string) => string): { label: string; href?: string }[] {
  const resolve = (label: string) => label.includes(".") ? t(label) : label;
  if (location === "/") return [{ label: t("nav.dashboard") }];
  const tryPaths: string[] = [];
  let current: string | undefined = location;
  while (current && current !== "/") {
    if (ROUTE_MAP[current]) { tryPaths.unshift(current); break; }
    const idx = current.lastIndexOf("/");
    current = idx > 0 ? current.slice(0, idx) : "/";
  }
  const chain: string[] = [];
  let cursor: string | undefined = tryPaths[0];
  const seen = new Set<string>();
  while (cursor && !seen.has(cursor)) {
    seen.add(cursor);
    chain.unshift(cursor);
    cursor = ROUTE_MAP[cursor]?.parent;
  }
  const crumbs: { label: string; href?: string }[] = [{ label: t("topbar.home"), href: "/" }];
  for (let i = 0; i < chain.length; i++) {
    const path = chain[i];
    const info = ROUTE_MAP[path];
    if (!info) continue;
    crumbs.push({
      label: resolve(info.label),
      href: i === chain.length - 1 ? undefined : path,
    });
  }
  if (crumbs.length === 1) crumbs.push({ label: t("topbar.page") });
  return crumbs;
}

// ─── TopBar (Odoo-style header) ───────────────────────────────────────────────
function TopBar({
  location, user, isSuperAdmin, onMobileMenu, onLogout,
}: {
  location: string;
  user: any;
  isSuperAdmin: boolean;
  onMobileMenu: () => void;
  onLogout: () => void;
}) {
  const { t, i18n } = useTranslation();
  const [, navigate] = useLocation();
  const crumbs = useMemo(() => getBreadcrumbs(location, t), [location, t, i18n.language]);

  // Update browser tab title to current page name (so opening in a new tab shows the screen name)
  useEffect(() => {
    const last = crumbs[crumbs.length - 1]?.label;
    const appName = t("app.name", "ZATCA e-Invoicing");
    document.title = last && last !== t("topbar.page") ? `${last} — ${appName}` : appName;
  }, [crumbs, t]);

  return (
    <header className="sticky top-0 z-10 border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
      {/* Row 1: search + actions */}
      <div className="flex h-14 items-center gap-3 px-4 sm:px-6">
        <Button
          variant="ghost" size="icon" className="md:hidden -ms-2"
          onClick={onMobileMenu}
        >
          <Menu className="h-5 w-5" />
        </Button>

        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute end-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
          <Input
            type="search"
            placeholder={t("topbar.quickSearch")}
            className="h-9 pe-9 ps-3 bg-muted/40 border-transparent focus-visible:bg-card focus-visible:border-input"
          />
        </div>

        <div className="flex-1" />

        {/* Right cluster */}
        <div className="flex items-center gap-1">
          {/* Quick links to documents */}
          <Button variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-primary hover:bg-primary/10" title={t("nav.salesInvoices")}
            onClick={() => navigate("/sales/invoices")}>
            <ShoppingBag className="h-[18px] w-[18px]" />
          </Button>
          <Button variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-orange-600 hover:bg-orange-50" title={t("nav.salesReturns")}
            onClick={() => navigate("/sales/returns")}>
            <Undo2 className="h-[18px] w-[18px]" />
          </Button>
          <Button variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-primary hover:bg-primary/10" title={t("nav.purchaseInvoices")}
            onClick={() => navigate("/purchasing/invoices")}>
            <ShoppingCart className="h-[18px] w-[18px]" />
          </Button>
          <Button variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-orange-600 hover:bg-orange-50" title={t("nav.purchaseReturns")}
            onClick={() => navigate("/purchasing/returns")}>
            <RotateCcw className="h-[18px] w-[18px]" />
          </Button>
          <div className="h-5 w-px bg-border mx-1" />
          <LanguageSwitcher variant="compact" />
          <Button variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-foreground" title={t("topbar.help")}>
            <HelpCircle className="h-[18px] w-[18px]" />
          </Button>
          <NotificationBell />
          <div className="h-5 w-px bg-border mx-1" />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-2 rounded-lg px-2 py-1 hover:bg-accent transition-colors">
                <Avatar className="h-7 w-7">
                  <AvatarFallback className={cn(
                    "text-[11px] font-bold",
                    isSuperAdmin ? "bg-purple-100 text-purple-700" : "bg-primary text-primary-foreground"
                  )}>
                    {user?.username?.[0]?.toUpperCase() ?? "م"}
                  </AvatarFallback>
                </Avatar>
                <div className="hidden lg:block text-start">
                  <p className="text-xs font-medium leading-tight">{user?.username ?? t("topbar.user")}</p>
                  <p className="text-[10px] text-muted-foreground leading-tight">
                    {isSuperAdmin ? t("topbar.superAdmin") : user?.role === "admin" ? t("topbar.manager") : t("topbar.user")}
                  </p>
                </div>
                <ChevronDown className="h-3.5 w-3.5 text-muted-foreground hidden lg:block" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuLabel className="font-normal">
                <div>
                  <p className="text-sm font-medium">{user?.username}</p>
                  <p className="text-xs text-muted-foreground">
                    {isSuperAdmin ? t("topbar.superAdmin") : user?.role === "admin" ? t("topbar.companyManager") : t("topbar.user")}
                  </p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild className="gap-2 cursor-pointer">
                <Link href="/settings">
                  <Settings className="h-4 w-4" />{t("topbar.accountSettings")}
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={onLogout} className="text-destructive focus:text-destructive gap-2">
                <LogOut className="h-4 w-4" />{t("topbar.logout")}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Row 2: breadcrumb + page title */}
      <div className="flex items-center gap-3 px-4 sm:px-6 py-2.5 border-t border-border/60 bg-muted/20">
        <nav className="flex items-center gap-1.5 text-xs flex-1 min-w-0 overflow-hidden">
          {crumbs.map((c, i) => {
            const isLast = i === crumbs.length - 1;
            return (
              <React.Fragment key={`${c.label}-${i}`}>
                {i > 0 && (i18n.dir() === "rtl"
                  ? <ChevronLeft className="h-3 w-3 text-muted-foreground/50 shrink-0" />
                  : <ChevronRight className="h-3 w-3 text-muted-foreground/50 shrink-0" />
                )}
                {c.href && !isLast ? (
                  <Link
                    href={c.href}
                    className="text-muted-foreground hover:text-foreground transition-colors truncate"
                  >
                    {i === 0 ? <Home className="h-3.5 w-3.5 inline -mt-0.5" /> : c.label}
                  </Link>
                ) : (
                  <span className={cn(
                    "truncate",
                    isLast ? "font-semibold text-foreground" : "text-muted-foreground"
                  )}>
                    {i === 0 && !isLast ? <Home className="h-3.5 w-3.5 inline -mt-0.5" /> : c.label}
                  </span>
                )}
              </React.Fragment>
            );
          })}
        </nav>
        <span className="hidden sm:inline-flex items-center gap-1.5 text-[11px] font-medium px-2 py-0.5 rounded-md bg-card border border-border/60 text-muted-foreground shrink-0">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
          {t("topbar.online")}
        </span>
      </div>
    </header>
  );
}

// ─── Main Layout ───────────────────────────────────────────────────────────────
export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const [mobileOpen, setMobileOpen]           = useState(false);
  const [dashboardOpen, setDashboardOpen]     = useState(() =>
    location === "/" ||
    ["/org/", "/zatca", "/general-settings", "/settings/currencies", "/settings/accounting-mappings", "/invoices", "/vat-declaration"].some(p => location.startsWith(p))
  );
  const [inventoryOpen, setInventoryOpen]     = useState(() => location.startsWith("/inventory") && !location.startsWith("/inventory/reports"));
  const [invReportsOpen, setInvReportsOpen]   = useState(() => location.startsWith("/inventory/reports"));
  const [reportsOpen, setReportsOpen]         = useState(() => location.startsWith("/accounting/reports"));
  const [purchasingOpen, setPurchasingOpen]   = useState(() => (location.startsWith("/purchasing") && !location.startsWith("/purchasing/reports")) || location.startsWith("/suppliers"));
  const [purchasingReportsOpen, setPurchasingReportsOpen] = useState(() => location.startsWith("/purchasing/reports"));
  const [salesOpen,      setSalesOpen]        = useState(() => (location.startsWith("/sales") && !location.startsWith("/sales/reports")) || location.startsWith("/customers"));
  const [salesReportsOpen, setSalesReportsOpen] = useState(() => location.startsWith("/sales/reports"));
  const [cashOpen,       setCashOpen]         = useState(() => location.startsWith("/cash") && !location.startsWith("/cash/reports"));
  const [cashReportsOpen, setCashReportsOpen] = useState(() => location.startsWith("/cash/reports"));
  const [accountingOpen, setAccountingOpen]   = useState(() => location.startsWith("/accounting/accounts") || location.startsWith("/accounting/journals"));
  const [hrOpen,         setHrOpen]           = useState(() => location.startsWith("/hr/"));

  const isSuperAdmin = user?.role === "superadmin";
  const menuPerms    = parseMenuPerms(user?.company?.menuPermissions);

  const handleDashboardToggle  = () => setDashboardOpen(v => !v);
  const handleInventoryToggle  = () => setInventoryOpen(v => !v);
  const handleInvReportsToggle = () => setInvReportsOpen(v => !v);
  const handleReportsToggle    = () => setReportsOpen(v => !v);
  const handlePurchasingToggle = () => setPurchasingOpen(v => !v);
  const handlePurchasingReportsToggle = () => setPurchasingReportsOpen(v => !v);
  const handleSalesToggle      = () => setSalesOpen(v => !v);
  const handleSalesReportsToggle = () => setSalesReportsOpen(v => !v);
  const handleCashToggle       = () => setCashOpen(v => !v);
  const handleCashReportsToggle = () => setCashReportsOpen(v => !v);
  const handleAccountingToggle = () => setAccountingOpen(v => !v);
  const handleHrToggle         = () => setHrOpen(v => !v);
  const closeMobile = () => setMobileOpen(false);

  const sharedProps = {
    location,
    isSuperAdmin,
    user,
    menuPerms,
    dashboardOpen,
    onDashboardToggle: handleDashboardToggle,
    inventoryOpen,
    onInventoryToggle: handleInventoryToggle,
    invReportsOpen,
    onInvReportsToggle: handleInvReportsToggle,
    reportsOpen,
    onReportsToggle: handleReportsToggle,
    purchasingOpen,
    onPurchasingToggle: handlePurchasingToggle,
    purchasingReportsOpen,
    onPurchasingReportsToggle: handlePurchasingReportsToggle,
    salesOpen,
    onSalesToggle: handleSalesToggle,
    salesReportsOpen,
    onSalesReportsToggle: handleSalesReportsToggle,
    cashOpen,
    onCashToggle: handleCashToggle,
    cashReportsOpen,
    onCashReportsToggle: handleCashReportsToggle,
    accountingOpen,
    onAccountingToggle: handleAccountingToggle,
    hrOpen,
    onHrToggle: handleHrToggle,
    onNavigate: closeMobile,
    onLogout: logout,
  };

  const { i18n } = useTranslation();
  const langCode = normalizeLang(i18n.language);
  const langMeta = SUPPORTED_LANGUAGES.find(l => l.code === langCode) ?? SUPPORTED_LANGUAGES[0];
  const isRtl = langMeta.dir === "rtl";

  return (
    <div className="flex min-h-screen w-full flex-col bg-background" dir={langMeta.dir}>
      {/* Desktop Sidebar */}
      <aside className={cn(
        "fixed inset-y-0 z-20 hidden w-64 flex-col bg-sidebar md:flex",
        isRtl ? "right-0 border-l border-border" : "left-0 border-r border-border"
      )}>
        <SidebarInner {...sharedProps} />
      </aside>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-30 bg-black/50 md:hidden" onClick={closeMobile} />
      )}
      <aside className={cn(
        "fixed inset-y-0 z-40 flex w-72 flex-col bg-sidebar transition-transform duration-200 md:hidden",
        isRtl
          ? `right-0 border-l border-border ${mobileOpen ? "translate-x-0" : "translate-x-full"}`
          : `left-0 border-r border-border ${mobileOpen ? "translate-x-0" : "-translate-x-full"}`
      )}>
        <SidebarInner {...sharedProps} />
      </aside>

      {/* Main content */}
      <div className={cn("flex flex-col min-h-screen", isRtl ? "md:mr-64" : "md:ml-64")}>
        <TopBar
          location={location}
          user={user}
          isSuperAdmin={isSuperAdmin}
          onMobileMenu={() => setMobileOpen(true)}
          onLogout={logout}
        />
        <main className="flex-1 p-4 sm:p-6 md:p-8 bg-muted/30">{children}</main>
      </div>
    </div>
  );
}
